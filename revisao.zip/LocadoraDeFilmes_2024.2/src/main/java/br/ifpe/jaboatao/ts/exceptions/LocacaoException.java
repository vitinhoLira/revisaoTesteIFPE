package br.ifpe.jaboatao.ts.exceptions;

public class LocacaoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8318222560499580074L;

	public LocacaoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
