package br.ifpe.jaboatao.ts.servicos;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import br.ifpe.jaboatao.ts.entidades.Filme;
import br.ifpe.jaboatao.ts.entidades.Locacao;
import br.ifpe.jaboatao.ts.entidades.Usuario;
import br.ifpe.jaboatao.ts.exceptions.LocacaoException;
import br.ifpe.jaboatao.ts.utils.DataUtils;

public class LocacaoServiceTest {
	
	private LocacaoService service;
	private static int cont = 0;
	@BeforeEach
	public void setup() {
		service = new LocacaoService();
//		cont++;
//		System.out.println(cont);
	}
	@Test
	@DisplayName("Locação com sucesso.")
	public void teste01() throws LocacaoException {
		// Cenário
//		LocacaoService service = new LocacaoService();
		Usuario usuario = new Usuario("Usuário 01");
//		Filme filme = new Filme("Filme 01", 2, 10.0);
		List<Filme> filmes = Arrays.asList(new Filme("Filme 01", 2, 10.0));

		// Ação
		Locacao locacao = service.alugarFilme(usuario, filmes);

		// Verificação
		Assertions.assertTrue(locacao.getUsuario().getNome() == "Usuário 01");
		Assertions.assertTrue(DataUtils.boDatasIguais(locacao.getDataLocacao(), new Date()));
		Assertions.assertTrue(DataUtils.boDatasIguais(locacao.getDataRetorno(), DataUtils.incrementarQntDias(1)));

	}

	@Test
	@DisplayName("Exception - Estoque vazio - Método try/catch")
	public void teste02() {
		// Cenário
//		LocacaoService service = new LocacaoService();
		Usuario usuario = new Usuario("João");
		List<Filme> filmes = Arrays.asList(new Filme("Filme 01", 0, 10.0));

		// Ação
		try {
			Locacao locacao = service.alugarFilme(usuario, filmes);
			Assertions.fail("Estoque deveria ser vazio.");
		} catch (LocacaoException e) {
			// Verificação
			Assertions.assertEquals("Filme sem estoque.", e.getMessage());
		}
	}

	@Test
	@DisplayName("Exception - Estoque vazio - Método assertionThrow")
	public void teste03() {
		//Cenário
//		LocacaoService service = new LocacaoService();
		Usuario usuario = new Usuario("Ana");
		List<Filme> filmes = Arrays.asList(new Filme("Filme 01", 0, 20.0));
		
		//Ação
		LocacaoException e = Assertions.assertThrows(LocacaoException.class, () -> {
			service.alugarFilme(usuario, filmes);
		}, "O estoque deveria ser zero.");
		//Verificacao
		Assertions.assertEquals("Filme sem estoque.", e.getMessage());
	}
	@Test
	@DisplayName("Exception - Filme null - Método try/catch")
	public void teste04() {
		// Cenário
//		LocacaoService service = new LocacaoService();
		Usuario usuario = new Usuario("João");
		List<Filme> filmes = null;

		// Ação
		try {
			Locacao locacao = service.alugarFilme(usuario, filmes);
			Assertions.fail("Filme deveria ser null.");
		} catch (LocacaoException e) {
			// Verificação
			Assertions.assertEquals("Filme nulo.", e.getMessage());
		}
	}

	@Test
	@DisplayName("Exception - Filme null - Método assertionThrow")
	public void teste05() {
		//Cenário
//		LocacaoService service = new LocacaoService();
		Usuario usuario = new Usuario("Ana");
		List<Filme> filmes = null;
		
		//Ação
		LocacaoException e = Assertions.assertThrows(LocacaoException.class, () -> {
			service.alugarFilme(usuario, filmes);
		}, "Filme deveria ser null.");
		//Verificacao
		Assertions.assertEquals("Filme nulo.", e.getMessage());
	}
	
	@Test
	@DisplayName("Locação de dois filmes")
	public void teste06() throws LocacaoException {
		//Cenário
		Usuario usuario = new Usuario("Usuário");
		List<Filme> filmes = 
				Arrays.asList(
						new Filme("Filme 01", 11, 10.0), 
						new Filme("Filme 02", 22, 11.0));
				
		//Ação
		Locacao locacao = service.alugarFilme(usuario, filmes);
		
		//Verificacao
		Assertions.assertEquals(21.0, locacao.getValorLocacao());
	}
	
}
