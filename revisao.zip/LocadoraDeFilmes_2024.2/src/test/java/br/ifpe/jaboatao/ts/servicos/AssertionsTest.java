package br.ifpe.jaboatao.ts.servicos;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import br.ifpe.jaboatao.ts.entidades.Usuario;

public class AssertionsTest {

	@Test
	public void teste01() {
		Assertions.assertTrue(true);
		Assertions.assertFalse(false);
	}
	
	@Test
	public void teste02() {
		//Number
		Assertions.assertEquals(1, 1, "Os número deveriam ser iguais.");
		Assertions.assertNotEquals(1, 2);
		Assertions.assertEquals(1, 1.0);
		Assertions.assertEquals(Math.PI, 3.1415, 0.0001);
		
		//String
		Assertions.assertEquals("Casa", "Casa");
		Assertions.assertEquals("Casa".toLowerCase(), "casa".toLowerCase());
		Assertions.assertTrue("Casa".equalsIgnoreCase("casa"));
		
		//Objetos
		Usuario u1 = new Usuario("Usuario 01");
		Usuario u2 = new Usuario("Usuario 01");
		
		Assertions.assertEquals(u1, u2);
		
	}
	@Test
	public void teste03() {
		//Objetos
		Usuario u1 = new Usuario("Usuario 01");
		Usuario u2 = new Usuario("Usuario 01");
		Usuario u3 = u1;
		Assertions.assertSame(u1, u3);
		Assertions.assertNotSame(u1, u2);
	}
	
	@Test
	public void teste04() {
		Usuario u4 = new Usuario("Usuario 04");
		Usuario u5 = null;
		
		Assertions.assertNull(u5);
		Assertions.assertNotNull(u4,"Não deveria ser null");
		
	}
	
}
