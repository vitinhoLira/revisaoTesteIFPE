package br.ifpe.jaboatao.ts.servicos;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import br.edu.ifpe.jaboatao.ts.entidades.Cliente;
import br.edu.ifpe.jaboatao.ts.entidades.Locacao;
import br.edu.ifpe.jaboatao.ts.entidades.Roupa;
import br.edu.ifpe.jaboatao.ts.exceptions.ProjetoException;
import br.edu.ifpe.jaboatao.ts.servicos.LocacaoService;

public class ServiceTest {
	

	@Test
	@DisplayName("Valor calculado com sucesso.")
	public void cenario01() throws ProjetoException {
		//Crie um teste com 5 roupas e teste se o valor da locação está sendo calculado corretamente.
		//public Roupa(String nome, String tamanho, Integer estoque, Double valor) {
		
		
		
		
		List<Roupa> roupas = Arrays.asList(
				
		new Roupa("teste1", "1.5", 5, 1.0),
		
		new Roupa("teste2", "8.5", 10, 165465.0),
		
		new Roupa("teste3", "6.5", 11, 189.0),
		
		new Roupa("teste4", "8.5", 16, 18.0),
	
		new Roupa("teste5", "5.5", 32, 15.0)
		
		);
		
		Cliente cliente1 = new Cliente("teste1");
		
		LocacaoService locacao = new LocacaoService();
		
		locacao.alugarRoupa(cliente1, roupas);
		
		
		
		
		
		
		
		
	}

}
