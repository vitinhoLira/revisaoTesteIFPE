package br.edu.ifpe.jaboatao.ts.servicos;

//br.edu.ifpe.jaboata.ts.servicos
import java.util.Date;
import java.util.List;

import br.edu.ifpe.jaboatao.ts.entidades.Cliente;
import br.edu.ifpe.jaboatao.ts.entidades.Locacao;
import br.edu.ifpe.jaboatao.ts.entidades.Roupa;
import br.edu.ifpe.jaboatao.ts.exceptions.ProjetoException;
import br.edu.ifpe.jaboatao.ts.utils.ManipulandoDatas;

public class LocacaoService {

	public Locacao alugarRoupa(Cliente cliente, List<Roupa> roupas) throws ProjetoException {
		
		Locacao locacao = new Locacao();

		for (Roupa roupa:roupas) {
			
			if (roupa.getValor() < 0) {

				throw new ProjetoException("Exceção: Verificar valor da roupa.");

			}

			if (roupa.getValor().equals(null)) {

				throw new ProjetoException("Exceção: Roupa nula.");

			}
			
			locacao.setRoupa(roupa);
			locacao.setCliente(cliente);
			locacao.setDataLocacao(new Date());
			locacao.setValorLocacao(roupa.getValor());
			// Definir a entrega para 3 dias depois.
			Date dataEntrega = ManipulandoDatas.novaDataComDiferencaDeDias(3);
			locacao.setDataRetorno(dataEntrega);
			
		}	
		
		return locacao;
	}

	public static void main(String[] args) {
		System.out.println("Funcionando.");
	}
}